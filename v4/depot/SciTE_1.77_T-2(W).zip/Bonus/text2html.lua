--pour que tout le script ne soit consid�r� que comme une seule action par la fonction "annuler"
editor:BeginUndoAction()

--tableau des �quivalences
local remplacements = {
        ["�"] ="&laquo;", ["�"] = "&Otilde;",
        ["�"] = "&not;", ["�"] = "&Ouml;",
        ["�"] = "&shy;", ["�"] = "&times;",
        ["�"] = "&reg;", ["�"] ="&Oslash;",
        ["�"] = "&masr;", ["�"] = "&Ugrave;",
        ["�"] = "&deg;", ["�"] = "&Uacute;",
        ["�"] = "&plusmn;", ["�"] = "&Ucirc;",
        ["�"] = "&sup2;", ["�"] = "&Uuml;",
        ["�"] = "&sup3;", ["�"] = "&Yacute;",
        ["�"] = "&acute;", ["�"] = "&THORN",
        ["�"] = "&micro;", ["�"] = "&szlig;",
        ["�"] = "&para;", ["�"] = "&agrave;",
        ["�"] = "&middot;", ["�"] = "&aacute;",
        ["�"] = "&cedil;", ["�"] = "&acirc;",
        ["�"] = "&sup1;", ["�"] = "&atilde;",
        ["�"] = "&ordm;", ["�"] ="&auml;",
        ["�"] = "&raquo;", ["�"] = "&aring;",
        ["�"] = "&frac14;", ["�"] = "&aelig;",
        ["�"] = "&frac12;", ["�"] = "&ccedil;",
        ["�"] = "&frac34;", ["�"] = "&egrave;",
        ["�"] = "&iquest;", ["�"] = "&eacute;",
        ["�"] = "&Agrave;", ["�"] = "&ecirc;",
        ["�"] = "&Aacute;", ["�"] = "&euml;",
        ["�"] = "&Acirc;", ["�"] = "&igrave;",
        ["�"] = "&Atilde;", ["�"] = "&iacute;",
        ["�"] = "&Auml;", ["�"] = "&icirc;",
        ["�"] = "&Aring;", ["�"] = "&iuml;",
        ["�"] = "&oelig;", ["�"] = "&Aelig", ["�"] = "&eth;",
        ["�"] = "&Ccedil;", ["�"] = "&ntilde;",
        ["�"] = "&Egrave;", ["�"] = "&ograve;",
        ["�"] = "&Eacute;", ["�"] = "&oacute;",
        ["�"] = "&pound;", ["�"] = "&Iacute;", ["�"] = "&divide;",
        ["�"] = "&curren;", ["�"] = "&Icirc;", ["�"] = "&oslash;",
        ["�"] = "&yen;", ["�"] = "&Iuml;", ["�"] = "&ugrave;",
        ["�"] = "&brvbar;", ["�"] = "&ETH;", ["�"] = "&uacute;",
        ["�"] = "&sect;", ["�"] = "&Ntilde;", ["�"] ="&ucirc;",
        ["�"] = "&uml;", ["�"] = "&Ograve;", ["�"] = "&uuml;",
        ["�"] = "&copy;", ["�"] = "&Oacute;", ["�"] = "&yacute;",
        ["�"] = "&ordf;", ["�"] = "&Ocirc;", ["�"] ="&thorn;",
        ["�"] ="&yuml;",
        ["&"] = "&amp;",
        ["<"] = "&lt;", [">"] = "&gt;",
        ["\""] = "&quot;",
}


-- caract�res sp�ciaux � rechercher
local caracteres = "�լ֭׮دٰڱ۲ܳݴ޵߶������������������������������������������������������&<>\""

-- d�but et fin de la selection
local cDeb = editor.SelectionStart
local cFin = editor.SelectionEnd

-- fin du document
local finDoc = editor.Length

-- diff�rence entre la fin du document et la fin de la s�lection
local diffFins = finDoc - cFin

-- variable utilis�e pour la recherche
local c = cDeb

-- tant qu'on est pas � la fin de la s�lection
while c<cFin do

   -- on cherche le prochain caract�re sp�cial
   local x = editor:findtext("["..caracteres.."]",SCFIND_REGEXP,c)
   
   -- s'il n'y en a plus ou si on d�passe la fin de s�lection on arr�te la boucle
   if not x or x>=cFin then break end   y = x+1
   
   -- on s�lectionne le caract�re trouv�
   editor:SetSel(x,y)
   
   -- on d�termine quel est le caract�re
   local lettre = editor:GetSelText()
   
   -- on cherche l'entit� HTML correspondante (dans les tableau remplacements)
   local rempl = remplacements[lettre]
   
   -- on remplace le caract�re par l'entit�
   editor:ReplaceSel(rempl)
   
   -- on d�termine la longueur suppl�mentaire cr�e par l'entit� par rapport au caract�re
   lgHTML = string.len(rempl)-1;
   
   -- on d�place le curseur en cons�quence
   c = x + lgHTML
   
   -- on recherche la fin du document et on d�termine la nouvelle position de la fin de s�lection
   finDoc = editor.Length
   cFin = finDoc - diffFins   
   
end--while

-- on replace le curseur au d�but de la s�lection
editor:GotoPos(cDeb)

-- fin de l'action pour la fonction "annuler"
editor:EndUndoAction()