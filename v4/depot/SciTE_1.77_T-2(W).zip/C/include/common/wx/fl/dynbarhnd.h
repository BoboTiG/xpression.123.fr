/////////////////////////////////////////////////////////////////////////////
// Name:        dynbarhnd.h
// Purpose:     This header simply includes controlbar.h.
// Author:      Aleksandras Gluchovas
// Modified by:
// Created:     23/01/99
// RCS-ID:      $Id: dynbarhnd.h,v 1.4 2005/09/23 12:46:56 MR Exp $
// Copyright:   (c) Aleksandras Gluchovas
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef __DYNBARHND_G__
#define __DYNBARHND_G__

#include "wx/fl/controlbar.h"

#endif /* __DYNBARHND_G__ */

