﻿<?php
	class lectureEnLigne {
	//
	// Tiger-222 - 10 Septembre 2008
	// révisée le 27 Septembre 2008
	//
	// http://xpression.123.fr
	//
	//
	// Informations sur la classe :
	//	Classe qui affiche les images contenues dans un dossier donné en paramètre.
	//	Utile pour les sites de scantrad pour un affichage des chapitres du genre
	//	"lecture en ligne" ou tout simplement pour afficher ses photos de vacances
	//	sur son site perso.
	//
	//
	// Note :
	//	La première fois que ce script est lancé, il peut prendre un peu de temps
	//	suivant le nombre d'images qu'il y a dans le dossier.
	//
	//
	// Fonctionnement de la classe :
	//	Pour instancier la classe : $test = new lecureEnLigne('dossier', 'paremetre_ur', 'auteur_miniatures);
	//	Pour afficher une image : $test->image_courante();
	//	Pour récupérer le numéro de l'image précédente : $test->precedente();
	//	Pour récupérer le numéro de l'image suivante : $test->suivante();
	//	Pour récupérer le talbeau des miniatures : $test->lister_miniatures();
	//
	//
	// Exemple :
	//	1. On instancie la classe
	//		try
	//		{
	//			$test = new lectureEnLigne('[MFT] Naruto Chapitre 416', 'img', 50);
	//		}
	//		catch (Exception $e)
	//		{
	//			echo $e->getMessage();
	//		}
	//
	//	2. On affiche l'image courante
	//		echo '<img src="'.$test->image_courante().'" />';
	//
	//	3. Un lien vers l'image précédente
	//		echo '<a href="'.$test->precedente().'>Image précédente</a>';
	//
	//	4. Un lien vers l'image suivante
	//		echo '<a href="'.$test->suivante().'>Image suivante</a>';
	//
	//	5. Affichage des miniatures
	//		A - Solution 1 : lister toutes les miniatures
	//			$miniatures = $test->lister_miniatures();
	//			foreach ($miniatures as $miniature)
	//			{
	//				echo
	//					'<a href="'.$miniature['lien'].'" alt="'.$miniature['titre'].'" >'
	//					.'<img src="'.$miniature['chemin'].'" /></a> ';
	//			}
	//
	//		B - Solution 2 : lister seulement 3 miniatures : celle de l'image précédente, l'actuelle et la suivante.
	//			$miniatures = $test->trois_miniatures();
	//			foreach ($miniatures as $miniature)
	//			{
	//				echo
	//					'<a href="'.$miniature['lien'].'" alt="'.$miniature['titre'].'" >'
	//					.'<img src="'.$miniature['chemin'].'" /></a> ';
	//			}
	//
	//
	// A vous d'adapter le tout à votre guise !
	//
	//
	// Note : un grand merci à CodeFalse pour son aide (http://www.reflectiv.net).
	//



		// Variable pour les erreurs
		private $_erreur = array(
			0 => 'La bibliothèque GD n\'est pas installée.',
			1 => 'Veuillez indiquer un dossier à traiter.',
			2 => 'Le dossier n\'existe pas.',
			3 => 'Le dossier n\'est pas accessible en lecture.',
			4 => 'Impossible de faire une copie de l\'image.',
			5 => 'Il n\'y a aucune image dans le dossier.');



		//
		// Fonction de consctruction de la classe.
		//
		// Prend trois arguments :
		//	- le dossier à traiter
		//	- le nom de la variable URL
		//	- la hauteur des miniatures
		//
		public function __construct($dossier = NULL, $param_url = NULL, $nouvelle_hauteur = 80)
		{
			// La bibliothèque GD est-elle présente ?
			$this->_test_gd();

			// Variables
			$this->dossier = $dossier;
			$this->param_url = $param_url;
			$this->nouvelle_hauteur = $nouvelle_hauteur;

			// Testons les variables
			$this->_test_dossier();

			if ( empty($this->nouvelle_hauteur) || !is_numeric($this->nouvelle_hauteur) || $this->nouvelle_hauteur < 1 )
			{
				$this->nouvelle_hauteur = 80;
			}
			if ( empty($this->param_url) )
			{
				$this->param_url = 'imgLeL';
			}

			// Remplissons le tableau des images
			$this->_listage();
		}



		// #########################################################
		//  Fonctions de tests

		//
		// Fonction qui teste la présence de la bibliothèque GD.
		//
		private function _test_gd()
		{
			if ( !function_exists('gd_info') )
			{
				throw new Exception ($this->_erreur['0']);
			}
		}

		//
		// Fonction qui teste la validité d'un dossier.
		//
		private function _test_dossier()
		{
			if ( empty($this->dossier) )
			{
				throw new Exception ($this->_erreur['1']);
			}
			elseif ( !is_dir($this->dossier) )
			{
				throw new Exception ($this->_erreur['2']);
			}
			elseif ( !is_readable($this->dossier) )
			{
				throw new Exception ($this->_erreur['3']);
			}
		}

		//
		// Fonction qui teste la validité d'une image.
		//
		private function _is_image()
		{
			if ( is_file($this->dossier.'/'.$this->fichier) )
			{
				$this->infos = getimagesize($this->dossier.'/'.$this->fichier);

				if ( $this->infos['mime'] === 'image/jpeg' )
				{
					return 'jpeg';
				}
				elseif ( $this->infos['mime'] == 'image/png' )
				{
					return 'png';
				}
			}
		}



		// #########################################################
		// Moteur

		//
		// Fonction qui créé un tableau contenant les images du dossier.
		//
		private function _listage()
		{
			$action = opendir($this->dossier);
			$this->i = 0;
			$this->tableau = array();

			// Listons les images dans un tableau :
			while ($this->fichier = readdir($action))
			{
				// S'agit-il d'une image valable ?
				if ( $this->_is_image() === 'jpeg' || $this->_is_image() === 'png' )
				{
					// S'agit-il d'une miniature ?
					if ( !ereg('mini_', $this->fichier) )
					{
						$this->tableau[$this->i] = $this->fichier; // Ajout des fichiers dans un tableau
					}
					//elseif ( ) // verifions la taille actuelle de la miniature
				}
				++$this->i;
			}
			closedir($action);

			// Trions les entrées du tableau
			sort($this->tableau);

			// Comptons le nombre d'entrées
			$this->total = count($this->tableau);

			// Retournons le tableau... ou l'erreur
			if ( $this->total < 1 )
			{
				throw new Exception ($this->_erreur['5']);
			}
			else
			{
				return $this->tableau;
			}
		}

		//
		// Fonction qui retourne diverses informations sur l'image.
		//
		private function _infos_image()
		{
			// Informations de l'image actuelle
			$this->infos = getimagesize($this->image);
			$this->largeur_actuelle = $this->infos['0'];
			$this->hauteur_actuelle = $this->infos['1'];
		}

		//
		// Fonction qui retourne diverses informations sur la miniature.
		//
		private function _infos_vignette()
		{
			// Informations de l'image actuelle
			$this->infos = getimagesize($this->vignette);
			$this->hauteur_actuelle_vignette = $this->infos['1'];
		}

		//
		// Fonction qui permet de redimensionner une image.
		//
		private function _redimensionner()
		{
			// Nouvelle image
			if ( $this->infos['mime'] === 'image/jpeg' )
			{
				$this->nouvelle_image = imagecreatefromjpeg($this->image);
			}
			if ( $this->infos['mime'] === 'image/png' )
			{
				$this->nouvelle_image = imagecreatefrompng($this->image);
			}

			// Calculons le coefficient de redimensionnement et la nouvelle largeur en conséquence
			$this->coefficient = $this->nouvelle_hauteur * 100 / $this->hauteur_actuelle;
			$this->coefficient = round($this->coefficient);
			$this->nouvelle_largeur = $this->coefficient * $this->largeur_actuelle / 100;

			// Miniature
			//
			// Format de la commande imagecreatetruecolor :
			//	- la largeur de l'image créée
			//	- la hauteur de l'image créée
			//
			$this->img_mini = imagecreatetruecolor ($this->nouvelle_largeur, $this->nouvelle_hauteur);

			//
			// Format de la commande imagecopyresampled :
			//	- image de destination
			//	- image source
			//	- point de départ en x de l'image de destination
			//	- point de départ en yde l'image de destination
			//	- point de départ en x de l'image source
			//	- point de départ en y de l'image source
			//	- largeur de l'image de destination
			//	- hauteur de l'image de destination
			//	- largeur de l'image source
			//	- hauteur de l'image source
			//
			imagecopyresampled($this->img_mini, $this->nouvelle_image, 0, 0, 0, 0, $this->nouvelle_largeur, $this->nouvelle_hauteur, $this->largeur_actuelle, $this->hauteur_actuelle);

			// Création
			if ( $this->infos['mime'] === 'image/jpeg' )
			{
				//
				// Format de la commande imagejpg :
				//	- l'image à traiter
				//	- le nom de sortie (si vide, alors la sortie est le navigateur)
				//	- la qualité de l'image
				//
				imagejpeg($this->img_mini, $this->vignette, 100);
			}
			if ( $this->infos['mime'] === 'image/png' )
			{
				//
				// Format de la commande imagepng :
				//	- l'image à traiter
				//	- le nom de sortie (si vide, alors la sortie est le navigateur)
				//
				imagepng($this->img_mini, $this->vignette);
			}

			// Suppression des images temporaires
			imagedestroy($this->nouvelle_image);
			imagedestroy($this->img_mini);
		}

		//
		// Fonction pour la création de la vignette.
		//
		private function _miniature()
		{
			// Informations sur l'image
			$this->_infos_image();

			// La miniature exite t-elle dékà ?
			if ( !file_exists($this->vignette) ) // Existe t-elle déjà ?
			{
				// Créons la miniature :
				if ( copy($this->image, $this->vignette) )
				{
					$this->_redimensionner(); // Nouvelle vignette à partir de l'image
				}
				else
				{
					throw new Exception ($this->_erreur['4']);
				}
			}
			else
			{
				// Informations sur l'image
				$this->_infos_vignette();

				// Voyons si la miniature actuelle répond bien à la hauteur demandée
				if ( $this->hauteur_actuelle_vignette <> $this->nouvelle_hauteur )
				{
					$this->_redimensionner(); // Nouvelle vignette à partir de l'image
				}
			}
		}

		//
		// Fonction pour la navigation entre les images.
		//
		private function _navigation()
		{
			if ( isset($_GET[$this->param_url]) && !empty($_GET[$this->param_url]) && is_numeric($_GET[$this->param_url]) )
			{
				if ( $_GET[$this->param_url] == 0 ) // S'il s'agit de la première image
				{
					$this->precedent = 0;
					$this->suivant = $_GET[$this->param_url] + 1;
				}
				elseif ( $_GET[$this->param_url] > $this->total - 2 ) // S'il s'agit de la dernière image
				{
					$this->precedent = $this->total - 2;
					$this->suivant = $this->total - 1;
				}
				else
				{
					$this->precedent = $_GET[$this->param_url] - 1;
					$this->suivant = $_GET[$this->param_url] + 1;
				}
			}
			else // Aucune variable donc on considère qu'il s'agit de la 1ère image
			{
				$this->precedent = 0;
				$this->suivant = 1;
			}
		}

		//
		// Fonction qui renvoie l'URL complète de la page.
		//
		private function _url_courante()
		{
			// Informations :
			//	$_SERVER['HTTP_HOST'] renvoie 127.0.0.1 ou www.site.fr
			//	$_SERVER['SCRIPT_NAME'] renvoie index.php
			//	$_SERVER['QUERY_STRING'] renvoie les paramètres passés à l'URL

			$this->url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME'];

			// Transférons le nombre contenu dans le paramètre
			if ( !empty($_GET[$this->param_url]) )
			{
				$nombre = $_GET[$this->param_url];
			}
			else
			{
				$nombre = '';
			}

			if ( !empty($_SERVER['QUERY_STRING']) ) // S'il y a un ou plusieurs paramètres dans l'URL
			{
				if ( ereg($this->param_url, $_SERVER['QUERY_STRING']) ) // Si dans ces paramètres, il y a $this->param_url, alors il faut l'enlever
				{

					// Détruisons le paramètre
					unset($_GET[$this->param_url]);

					// Comptons le nombre d'entrées de $_GET pour voir s'il y a d'autres paramètres
					$nb_param = count($_GET);

					if ( $nb_param == 0 ) // S'il n'y a pas d'autres paramètres
					{
						// Reconstruisons l'URL sans le paramètre $this->param_url
						$this->url .= '?';
					}
					else
					{
						// Reconstruisons l'URL sans le paramètre $this->param_url
						$this->url .= '?'.http_build_query($_GET).'&';
					}
				}
				else
				{
					$this->url .= '?'.$_SERVER['QUERY_STRING'].'&';
				}
			}
			else
			{
				$this->url .= '?';
			}

			// Redonnons le nombre au paramètre
			$_GET[$this->param_url] = $nombre;

			// Retournons l'URL complète prète à l'emploi
			return $this->url.$this->param_url.'=';
		}



		// #########################################################
		// Résultats

		//
		// Fonction pour l'image précédente.
		//
		public function precedente()
		{
			// Calculons le numéro de l'image précédente
			$this->_navigation();

			return $this->_url_courante().$this->precedent;
		}

		//
		// Fonction pour l'image suivante.
		//
		public function suivante()
		{
			// Calculons le numéro de l'image suivante
			$this->_navigation();

			return $this->_url_courante().$this->suivant;
		}

		//
		// Fonction qui affiche l'image courante. Si aucune, alors la première du tableau.
		//
		public function image_courante()
		{
			if ( isset($_GET[$this->param_url]) && !empty($_GET[$this->param_url]) && is_numeric($_GET[$this->param_url]) )
			{
				if ( $_GET[$this->param_url] > $this->total - 2 ) // S'il s'agit de la dernière image
				{
					$this->numero_actuel = $this->total - 1; // Variable utile pour a fonction trois_miniatures()
					return $this->dossier.'/'.$this->tableau[$this->total - 1];
				}
				elseif ( !array_key_exists($_GET[$this->param_url], $this->tableau) ) // Si la valeur du paramètre est hors tableau
				{
					$this->numero_actuel = 0;
					return $this->dossier.'/'.$this->tableau['0'];
				}
				else
				{
					$this->numero_actuel = $_GET[$this->param_url];
					return $this->dossier.'/'.$this->tableau[$_GET[$this->param_url]];
				}
			}
			else
			{
				$this->numero_actuel = 0;
				return $this->dossier.'/'.$this->tableau['0'];
			}
		}

		//
		// Fonction qui liste toutes les miniatures dans un tableau.
		//
		public function lister_miniatures()
		{
			//  Variable
			$this->tab_miniatures = array();

			for ($this->j = 0; $this->j < $this->total; ++$this->j)
			{
				// Variables :
				$this->image = $this->dossier.'/'.$this->tableau[$this->j]; // Chemin de l'image taille normale
				$this->vignette =  $this->dossier.'/mini_'.$this->tableau[$this->j]; // Chemin de la vignette

				// Voyons si la miniature existe, sinon on la créé
				$this->_miniature();

				// On ajoute tout ça dans un tableau
				$this->tab_miniatures[$this->j]['lien'] = $this->_url_courante().$this->j; // Numéro de l'image dans le tableau, pour le lien
				$this->tab_miniatures[$this->j]['titre'] = $this->tableau[$this->j]; // Nom de l'image
				$this->tab_miniatures[$this->j]['chemin'] = $this->vignette; // Chemin de la miniature
			}

			// Retournons le tableau
			return $this->tab_miniatures;
		}

		//
		// Fonction qui renvoi un tableau contenant 3 miniatures, celle de l'image précédente, l'actuelle et la suivante.
		//
		public function trois_miniatures()
		{
			// Variable
			$this->tab_trois_miniatures = array();

			// On ajoute tout ça dans un tableau
			for ( $this->j = 0; $this->j < 3; ++$this->j )
			{
				// Déterminons le numero de l'image
				if ( $this->j == 0 ) // Entrée précédente dans le tableau
				{
					if ( $this->numero_actuel == 0 )
					{
						$this->num = $this->numero_actuel;
					}
					else
					{
						$this->num = $this->numero_actuel - 1;
					}
				}
				elseif ( $this->j == 1 ) // Entrés actuelle dans le tableau
				{
					$this->num = $this->numero_actuel;
				}
				else // Entreé suivante dans le tableau
				{
					if ( $this->numero_actuel > $this->total - 2 )
					{
						$this->num = $this->numero_actuel;
					}
					else
					{
						$this->num =  $this->numero_actuel + 1;
					}
				}

				// Variables :
				$this->image = $this->dossier.'/'.$this->tableau[$this->num]; // Chemin de l'image taille normale
				$this->vignette =  $this->dossier.'/mini_'.$this->tableau[$this->num]; // Chemin de la vignette

				// Voyons si la miniature existe, sinon on la créé
				$this->_miniature();

				// Miniature précédente
				$this->tab_trois_miniatures[$this->j]['lien'] = $this->_url_courante().$this->num; // Numéro de l'image dans le tableau, pour le lien
				$this->tab_trois_miniatures[$this->j]['titre'] = $this->tableau[$this->num]; // Nom de l'image
				$this->tab_trois_miniatures[$this->j]['chemin'] = $this->vignette; // Chemin de la miniature
			}

			// Retournons le tableau
			return $this->tab_trois_miniatures;
		}
	}
?>
