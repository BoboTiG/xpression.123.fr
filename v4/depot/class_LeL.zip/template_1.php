﻿<?php

	//
	// Template pour un affichage de toutes les vignettes.
	//

	require('class_lectureEnLigne.php');

	try
	{
		$test = new lectureEnLigne('[MFT] Naruto Chapitre 416'); // instanciation de la classe
	}
	catch (Exception $e)
	{
		echo $e->getMessage();
	}

	// Conteneur général :
	echo '<div style="width:800px; overflow:hidden; padding:5px;">';

	// Affichage du titre
	echo '<h3 style="text-align:center;">Test</h3>';

	// ###
	// 1ère ligne - image actuelle :
	echo
		'<div style="text-align:center;">'
		.'<p><img src="'.$test->image_courante().'" style="border:none; max-width:790px; "/></p>'
		.'</div>';

	// ###
	// Affichage des flèches :
	echo
		'<p style="text-align:center;">'
		.'<a href="'.$test->precedente().'" title="Image précédente" '
		.'style="text-decoration:none;"><img src="fleche-gauche.gif" style="border:none;" /></a>'
		.'&nbsp; &nbsp; &nbsp;'
		.'<a href="'.$test->suivante().'" title="Image suivante" '
		.'style="text-decoration:none;"><img src="fleche-droite.gif" style="border:none;" /></a>'
		.'</p>';

	// Ligne de séparation
	echo '<hr style="height:1px; border:none; width:790px; background-color:black;"/>';

	// ###
	// 2ème ligne - liste des miniatures
	echo '<div style="text-align:center;">';

	// Affichage des vignettes :
	$miniatures = $test->lister_miniatures(); // Retourne un tableau contenant les miniatures du dossier
	foreach ($miniatures as $num)
	{
		echo
			'<a href="'.$num['lien'].'" title="'.$num['titre'].'" style="text-decoration:none;"> '
			.'<img src="'.$num['chemin'].'" style="margin:3px 5px; padding-left:0; padding-top:0; '
			.'padding-right:1px; padding-bottom:1px; border:none; border-bottom:2px solid grey; '
			.'border-right:2px solid grey;" /> </a> ';
	}

	// ###
	echo
		'</div>' // Fin de la ligne 2
		.'</div>'; // Fin du conteneur général
?>
