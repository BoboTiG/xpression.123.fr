﻿<?php

	//
	// Template pour un affichage de seulement 3 vignettes.
	//

	require('class_lectureEnLigne.php');

	try
	{
		$test = new lectureEnLigne('[MFT] Naruto Chapitre 416', '', 80); // instanciation de la classe
	}
	catch (Exception $e)
	{
		echo $e->getMessage();
	}

	// Affichage du titre
	echo '<h1 style="text-align:center;">'.$_GET['chapitre'].'</h1>';

	// Conteneur général :
	echo '<div style="width:700px; overflow:hidden;">';


	// ###
	// 1ère ligne - image actuelle :
	echo
		'<div style="text-align:center;">'
		.'<img src="'.$test->image_courante().'" style="border:none; max-width:690px; max-height:790px;"/>'
		.'</div>';

	// ###
	// 2ème ligne - liste des miniatures
	echo '<div style="text-align:center;">';

	echo	'<p style="text-align:center;">';

	$miniatures = $test->trois_miniatures(); // Retourne un tableau contenant les miniatures du dossier

	if ( $miniatures[0] <> $miniatures[1] )
	{
		// Affichage de l'image précédente :
		echo
			'<a href="'.$miniatures[0]['lien'].'" title="'.$miniatures[0]['titre'].'" style="text-decoration:none;"> '
			.'<img src="'.$miniatures[0]['chemin'].'" style="margin:3px 5px; padding-left:0; padding-top:0; '
			.'padding-right:1px; padding-bottom:1px; border:none; border-bottom:2px inset #999; '
			.'border-right:2px inset #999; vertical-align:middle;" /> </a> ';

		// Affichage de la flèche gauche :
		echo
			'<a href="'.$test->precedente().'" title="Image précédente" '
			.'style="text-decoration:none;"><img src="fleche-gauche.gif" style="border:none; vertical-align:middle;" /></a>'
			.'&nbsp; &nbsp; &nbsp;';
	}

	// Affichage de l'image actuelle :
	echo
		'<a href="'.$miniatures[1]['lien'].'" title="'.$miniatures[1]['titre'].'" style="text-decoration:none;"> '
		.'<img src="'.$miniatures[1]['chemin'].'" style="margin:3px 5px; padding-left:0; padding-top:0; '
		.'padding-right:1px; padding-bottom:1px; border:none; border-bottom:2px inset #999; '
		.'border-right:2px inset #999; vertical-align:middle;" /> </a> ';

	if ( $miniatures[1] <> $miniatures[2] )
	{
		// Affichage de la flèche droite :
		echo
			'<a href="'.$test->suivante().'" title="Image suivante" '
			.'style="text-decoration:none;"><img src="fleche-droite.gif" style="border:none; vertical-align:middle;" /></a>';

		// Affichage de l'image suivante :
		echo
			'<a href="'.$miniatures[2]['lien'].'" title="'.$miniatures[2]['titre'].'" style="text-decoration:none;"> '
			.'<img src="'.$miniatures[2]['chemin'].'" style="margin:3px 5px; padding-left:0; padding-top:0; '
			.'padding-right:1px; padding-bottom:1px; border:none; border-bottom:2px inset #999; '
			.'border-right:2px inset #999; vertical-align:middle;" /> </a> ';
	}

	echo '</p>';

	// ###
	echo
		'</div>' // Fin de la ligne 2
		.'</div>'; // Fin du conteneur général
?>
